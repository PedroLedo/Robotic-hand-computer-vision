#include <Servo.h>

Servo servos[5];  // 5 servos, um para cada dedo

// Pinos onde os servos estão conectados
int pinosServos[5] = {3, 5, 6, 9, 10};  // ajuste conforme seu circuito

void setup() {
  Serial.begin(9600);
  // Inicializa todos os servos
  for (int i = 0; i < 5; i++) {
    servos[i].attach(pinosServos[i]);
    servos[i].write(0); // posição inicial 0°
  }
}

void loop() {
  if (Serial.available()) {
    String comando = Serial.readStringUntil('\n');  // lê até o fim da linha

    // Garante que o comando tem pelo menos 5 caracteres
    if (comando.length() >= 5) {
      for (int i = 0; i < 5; i++) {
        if (comando.charAt(i) == '1') {
          servos[i].write(0);  // LED aceso -> servo 180°
        } else {
          servos[i].write(110);    // LED apagado -> servo 0°
        }
      }
    }
  }
}
